
model_names_list = 'ppo'
pbo_i = 83.33333333333333

figure_string = "{} $p$\n{}%".format(model_names_list, format(pbo_i, '.1f'))

print(figure_string)