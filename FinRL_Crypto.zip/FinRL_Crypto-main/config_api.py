'''
Enter your Binance API keys here.
'''

API_KEY_BINANCE = 'Enter your public key here!'
API_SECRET_BINANCE = 'Enter your secret key here!'